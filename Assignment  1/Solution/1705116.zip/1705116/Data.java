
import java.io.Serializable;
public class Data implements Serializable,Cloneable{

    public String message;
    public long sizeValue;
    public Object clone() throws CloneNotSupportedException {
        return super.clone();
    }
}

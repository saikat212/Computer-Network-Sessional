

public class Information {
    public String userid;
    public NetworkConnection netConnection;
    public Information(String user,NetworkConnection nConnection)
    {
        userid=user;
        netConnection=nConnection;
    }

}

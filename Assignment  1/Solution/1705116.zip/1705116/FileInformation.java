
public class FileInformation {
    String fileID;
    String fileName;
    String fileType;
    public FileInformation(String fID,String fName,String fType)
    {
        fileID=fID;
        fileName=fName;
        fileType=fType;
    }
}
